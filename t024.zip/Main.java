import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static class Product {
        String name;
        double price;
        String farmerName;

        Product(String name, double price, String farmerName) {
            this.name = name;
            this.price = price;
            this.farmerName = farmerName;
        }

        public String toString() {
            return name + " - Rs." + price + " (by " + farmerName + ")";
        }
    }

    static ArrayList<Product> products = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("=== Direct Market Platform ===");
            System.out.println("1. Farmer Login");
            System.out.println("2. Buyer Login");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1 -> farmerPanel();
                case 2 -> buyerPanel();
                case 3 -> {
                    System.out.println("Thank you! Exiting...");
                    System.exit(0);
                }
                default -> System.out.println("Invalid choice.\n");
            }
        }
    }

    static void farmerPanel() {
        System.out.print("Enter your name: ");
        String farmer = sc.next();
        System.out.print("Enter product name: ");
        String pname = sc.next();
        System.out.print("Enter price: ");
        double price = sc.nextDouble();
        products.add(new Product(pname, price, farmer));
        System.out.println("Product added successfully!\n");
    }

    static void buyerPanel() {
        if (products.isEmpty()) {
            System.out.println("No products available yet.\n");
            return;
        }
        System.out.println("Available Products:");
        for (int i = 0; i < products.size(); i++) {
            System.out.println((i + 1) + " " + products.get(i));
        }
        System.out.print("Enter product number to buy: ");
        int choice = sc.nextInt();
        if (choice > 0 && choice <= products.size()) {
            Product p = products.remove(choice - 1);
            System.out.println("You bought " + p.name + " from " + p.farmerName + "\n");
        } else {
            System.out.println("Invalid selection.\n");
        }
    }
}